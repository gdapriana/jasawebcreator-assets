<?php 
// Silence is Gold