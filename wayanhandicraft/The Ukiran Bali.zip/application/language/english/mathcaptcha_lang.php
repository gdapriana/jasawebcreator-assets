<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Words for numbers 1 to 100
 */
$lang['mathcaptcha_numeric_word_0'] = '0';
$lang['mathcaptcha_numeric_word_1'] = '1';
$lang['mathcaptcha_numeric_word_2'] = '2';
$lang['mathcaptcha_numeric_word_3'] = '3';
$lang['mathcaptcha_numeric_word_4'] = '4';
$lang['mathcaptcha_numeric_word_5'] = '5';
$lang['mathcaptcha_numeric_word_6'] = '6';
$lang['mathcaptcha_numeric_word_7'] = '7';
$lang['mathcaptcha_numeric_word_8'] = '8';
$lang['mathcaptcha_numeric_word_9'] = '9';
$lang['mathcaptcha_numeric_word_10'] = '10';
$lang['mathcaptcha_numeric_word_11'] = '11';
$lang['mathcaptcha_numeric_word_12'] = '12';
$lang['mathcaptcha_numeric_word_13'] = '13';
$lang['mathcaptcha_numeric_word_14'] = '14';
$lang['mathcaptcha_numeric_word_15'] = '15';
$lang['mathcaptcha_numeric_word_16'] = '16';
$lang['mathcaptcha_numeric_word_17'] = '17';
$lang['mathcaptcha_numeric_word_18'] = '18';
$lang['mathcaptcha_numeric_word_19'] = '19';
$lang['mathcaptcha_numeric_word_20'] = '20';
$lang['mathcaptcha_numeric_word_21'] = '21';
$lang['mathcaptcha_numeric_word_22'] = '22';
$lang['mathcaptcha_numeric_word_23'] = '23';
$lang['mathcaptcha_numeric_word_24'] = '24';
$lang['mathcaptcha_numeric_word_25'] = '25';
$lang['mathcaptcha_numeric_word_26'] = '26';
$lang['mathcaptcha_numeric_word_27'] = '27';
$lang['mathcaptcha_numeric_word_28'] = '28';
$lang['mathcaptcha_numeric_word_29'] = '29';
$lang['mathcaptcha_numeric_word_30'] = '30';
$lang['mathcaptcha_numeric_word_31'] = '31';
$lang['mathcaptcha_numeric_word_32'] = '32';
$lang['mathcaptcha_numeric_word_33'] = '33';
$lang['mathcaptcha_numeric_word_34'] = '34';
$lang['mathcaptcha_numeric_word_35'] = '35';
$lang['mathcaptcha_numeric_word_36'] = '36';
$lang['mathcaptcha_numeric_word_37'] = '37';
$lang['mathcaptcha_numeric_word_38'] = '38';
$lang['mathcaptcha_numeric_word_39'] = '39';
$lang['mathcaptcha_numeric_word_40'] = '40';
$lang['mathcaptcha_numeric_word_41'] = '41';
$lang['mathcaptcha_numeric_word_42'] = '42';
$lang['mathcaptcha_numeric_word_43'] = '43';
$lang['mathcaptcha_numeric_word_44'] = '44';
$lang['mathcaptcha_numeric_word_45'] = '45';
$lang['mathcaptcha_numeric_word_46'] = '46';
$lang['mathcaptcha_numeric_word_47'] = '47';
$lang['mathcaptcha_numeric_word_48'] = '48';
$lang['mathcaptcha_numeric_word_49'] = '49';
$lang['mathcaptcha_numeric_word_50'] = '50';
$lang['mathcaptcha_numeric_word_51'] = '51';
$lang['mathcaptcha_numeric_word_52'] = '52';
$lang['mathcaptcha_numeric_word_53'] = '53';
$lang['mathcaptcha_numeric_word_54'] = '54';
$lang['mathcaptcha_numeric_word_55'] = '55';
$lang['mathcaptcha_numeric_word_56'] = '56';
$lang['mathcaptcha_numeric_word_57'] = '57';
$lang['mathcaptcha_numeric_word_58'] = '58';
$lang['mathcaptcha_numeric_word_59'] = '59';
$lang['mathcaptcha_numeric_word_60'] = '60';
$lang['mathcaptcha_numeric_word_61'] = '61';
$lang['mathcaptcha_numeric_word_62'] = '62';
$lang['mathcaptcha_numeric_word_63'] = '63';
$lang['mathcaptcha_numeric_word_64'] = '64';
$lang['mathcaptcha_numeric_word_65'] = '65';
$lang['mathcaptcha_numeric_word_66'] = '66';
$lang['mathcaptcha_numeric_word_67'] = '67';
$lang['mathcaptcha_numeric_word_68'] = '68';
$lang['mathcaptcha_numeric_word_69'] = '69';
$lang['mathcaptcha_numeric_word_70'] = '70';
$lang['mathcaptcha_numeric_word_71'] = '71';
$lang['mathcaptcha_numeric_word_72'] = '72';
$lang['mathcaptcha_numeric_word_73'] = '73';
$lang['mathcaptcha_numeric_word_74'] = '74';
$lang['mathcaptcha_numeric_word_75'] = '75';
$lang['mathcaptcha_numeric_word_76'] = '76';
$lang['mathcaptcha_numeric_word_77'] = '77';
$lang['mathcaptcha_numeric_word_78'] = '78';
$lang['mathcaptcha_numeric_word_79'] = '79';
$lang['mathcaptcha_numeric_word_80'] = '80';
$lang['mathcaptcha_numeric_word_81'] = '81';
$lang['mathcaptcha_numeric_word_82'] = '82';
$lang['mathcaptcha_numeric_word_83'] = '83';
$lang['mathcaptcha_numeric_word_84'] = '84';
$lang['mathcaptcha_numeric_word_85'] = '85';
$lang['mathcaptcha_numeric_word_86'] = '86';
$lang['mathcaptcha_numeric_word_87'] = '87';
$lang['mathcaptcha_numeric_word_88'] = '88';
$lang['mathcaptcha_numeric_word_89'] = '89';
$lang['mathcaptcha_numeric_word_90'] = '90';
$lang['mathcaptcha_numeric_word_91'] = '91';
$lang['mathcaptcha_numeric_word_92'] = '92';
$lang['mathcaptcha_numeric_word_93'] = '93';
$lang['mathcaptcha_numeric_word_94'] = '94';
$lang['mathcaptcha_numeric_word_95'] = '95';
$lang['mathcaptcha_numeric_word_96'] = '96';
$lang['mathcaptcha_numeric_word_97'] = '97';
$lang['mathcaptcha_numeric_word_98'] = '98';
$lang['mathcaptcha_numeric_word_99'] = '99';
$lang['mathcaptcha_numeric_word_100'] = '100';


/**
 * Addition phrases for two numbers
 */
$lang['mathcaptcha_addition_2_1'] = 'What is !1 plus !2?';
$lang['mathcaptcha_addition_2_2'] = 'Add together !1 and !2';
$lang['mathcaptcha_addition_2_3'] = 'What do you get if you add !1 to !2?';
$lang['mathcaptcha_addition_2_4'] = 'Add !1 to !2, what do you get?';
$lang['mathcaptcha_addition_2_5'] = 'What is the sum of !1 and !2?';

/**
 * Subraction phrases for two numbers
 * In this case !2 is always >= !1
 */
$lang['mathcaptcha_subtraction_2_1'] = 'What is !2 minus !1?';
$lang['mathcaptcha_subtraction_2_2'] = 'Substract !1 from !2';
$lang['mathcaptcha_subtraction_2_3'] = 'Substract !1 from !2, what do you get?';
$lang['mathcaptcha_subtraction_2_4'] = 'What do you get if you substract !1 from !2?';
$lang['mathcaptcha_subtraction_2_5'] = 'What is the substraction !1 from !2?';

/**
 * Multiplication phrases for two numbers
 */
$lang['mathcaptcha_multiplication_2_1'] = 'What is !1 times !2?';
$lang['mathcaptcha_multiplication_2_2'] = 'What is !1 multiplied by !2?';
$lang['mathcaptcha_multiplication_2_3'] = 'Multiply !1 by !2, what do you get?';
$lang['mathcaptcha_multiplication_2_4'] = 'What do you get if you multiply !1 by !2?';
$lang['mathcaptcha_multiplication_2_5'] = 'What is the multiplication of !1 and !2?';

/**
 * Division phrases for two numbers
 * In this case !1 is a number we will divide
 */
$lang['mathcaptcha_division_2_1'] = 'Divide !1 by !2?';
$lang['mathcaptcha_division_2_2'] = 'What is !1 divided by !2?';
$lang['mathcaptcha_division_2_3'] = 'Divide !1 by !2, what do you get?';
$lang['mathcaptcha_division_2_4'] = 'What do yiu get if you divide !1 by !2?';
$lang['mathcaptcha_division_2_5'] = 'What is the division of !1 by !2?';

/* End of file mathcaptcha_lang.php */
/* Location: ./application/languages/english/mathcaptcha_lang.php */